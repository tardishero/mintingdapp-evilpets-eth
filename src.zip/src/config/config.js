module.exports = {
  // eslint-disable-next-line no-loss-of-precision
  MaxMintCount: 300,
  RoyalPetsContractAddr: "0x8cf4F00c2a7E5dC258449211509e56b033fd7C41",
};
