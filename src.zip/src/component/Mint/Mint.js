import { useState } from "react";
import CountdownTimer from "react-component-countdown-timer";

import Button from "../common/button";
import SliderNFT from "./Slider";

import MintStyleWrapper from "./Mint.style";

import checkIcon from "../../assets/images/icon/mint-right-text-icon.svg";
import discordIcon from "../../assets/images/icon/dis_logo.svg";
import twitterIcon from "../../assets/images/icon/Twitter.svg";

import config from "../../config/config";
import ROYALPETSABI from "../../assets/abis/royalPetsABI.json";

const ethers = require("ethers");

const Mint = (account, connect, disconnect) => {
  const provider = new ethers.providers.Web3Provider(window.ethereum);
  const Signer = provider.getSigner();

  const royalPetsContract = new ethers.Contract(
    config.RoyalPetsContractAddr,
    ROYALPETSABI,
    Signer
  );

  const mint = async () => {
    console.log("=>", royalPetsContract);

    await royalPetsContract.mint();
  };

  const counterSettings = {
    count: 3600 * 24,
    showTitle: true,
    size: 40,
    labelSize: 34,
    backgroundColor: "transparent",
    color: "#fff",
    fontWeight: 700,
    dayTitle: "D",
    hourTitle: "H",
    minuteTitle: "M",
    secondTitle: "S",
    id: "countdownwrap",
  };

  return (
    <MintStyleWrapper>
      <div className="container my-10">
        <div className="grid grid-cols-1 md:grid-cols-2">
          <div className="mint_left_content">
            <div className="mint_left_inner">
              <div className="mint_slider">
                <SliderNFT />
              </div>
              <ul className="mint_count_list">
                <li>
                  <h3 className="font-extrabold text-white">Remaining</h3>
                  <h3 className="font-extrabold text-white">0 / 300</h3>
                </li>
                <li>
                  <h3 className="font-extrabold text-white">Price</h3>
                  <h3 className="font-extrabold text-white">1250 SGB</h3>
                </li>
              </ul>
              <Button lg variant="mint" onClick={() => mint()}>
                {" "}
                Mint now
              </Button>
            </div>
          </div>
          <div className="mint_right_content">
            <div className="content_header">
              <h4 className="flex font-extrabold">
                WHITELIST : SOLDOUT
                <span className="">
                  <img src={checkIcon} alt="icon" />
                </span>
              </h4>

              <h1 className="font-bold">WhiteList MINT LIVE</h1>
            </div>

            <div className="mint_timer">
              <h3 className="font-extrabold text-lg text-white">
                Whitelist Mint End in
              </h3>
              <CountdownTimer {...counterSettings} className="font-extrabold" />
            </div>
            <div className="content_footer">
              <h5 className="font-bold">Price 1250 SGB</h5>
              <h5 className="font-bold">Mint is live until 25 apr 04:00H</h5>
            </div>
            <div className="flex gap-3 mt-3">
              <Button lg variant="outline">
                <img src={discordIcon} alt="icon" />
                join discord
              </Button>
              <Button lg variant="outline">
                <img src={twitterIcon} alt="icon" />
                join twitter
              </Button>
            </div>
          </div>
        </div>
      </div>
    </MintStyleWrapper>
  );
};

export default Mint;
